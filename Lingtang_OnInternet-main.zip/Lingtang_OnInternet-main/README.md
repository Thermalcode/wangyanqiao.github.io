# 电子灵堂

[在线演示 Demo](https://asoulfucker.github.io/Lingtang_OnInternet/)

#### 优点
 - 样式简单，一目了然。
 - 可随意新添内容，搭配性好。
 - 配置简单。

#### 使用

叉下来本项目，修改 index.html 头部中的配置。

修改 name，introduction，picture 等参数。

完成。
